<!--

Please use one of the following CodeSandboxes to reproduce your issue and make sure not to include any external libraries:

- @floating-ui/dom: https://codesandbox.io/s/floating-ui-dom-template-nzvvx
- @floating-ui/react-dom: << coming soon >>
- @floating-ui/react-native: << coming soon >>

-->

