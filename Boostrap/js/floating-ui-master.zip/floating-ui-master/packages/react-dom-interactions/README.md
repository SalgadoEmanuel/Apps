# @floating-ui/react-dom-interactions

This is the library to use Floating UI Interactions with React DOM.
